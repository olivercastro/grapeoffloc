// Cufon
jQuery(document).ready(function(){
   Cufon.replace('.new-links li a', {
 	        color:'#111;',
 	        fontWeight: 'bold',
			lineheight: '20px',
		}); 
	Cufon.replace('.left_a, .show_description_div h2, .container .container_left .show_content .show_price_div h2, .container .container_right h2,�, .retl_disc ul li.left', {
 	        
		});
		Cufon.replace('.uppertxt', {textTransform:'uppercase' });
	
});